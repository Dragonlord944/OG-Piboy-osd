Warning!!! Internet access may be required during installation

1. copy files/folders to /Boot/

If installing on a fresh image.
2. Replace init=... in cmdline.txt with: logo.nologo snd_bcm2835.enable_compat_alsa=1 init=/bin/bash -c "mount -t proc proc /proc; mount -t sysfs sys /sys; mount /boot; source /boot/unattended"

else if Updating on an image that had the Piboy software previously installed.
2. Add to the end of the first line in cmdline.txt: init=/bin/bash -c "mount -t proc proc /proc; mount -t sysfs sys /sys; mount /boot; source /boot/unattended"

3. Edit options in one-time-script.conf.  Primarily the wifi settings need to be set, OR just connect an ethernet cable from the Piboy to your network.  Assums DHCP is enabled on your router.

After files are copied and cmdline.txt is edited, place the SD card in the Piboy and power on
